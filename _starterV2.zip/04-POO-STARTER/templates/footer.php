
<!-- Pied de Page -->
<div class="container">
    <footer class="mt-4 pt-4 border-top">
        <div class="row">
            <div class="col-12">
                <h5>Mon Site POO</h5>
                <small class="d-block text-muted">
                    &copy; <?= date('Y') ?>
                </small>
            </div>
        </div>
    </footer>
</div>
<!-- Fin Pied de Page -->

</body>
</html>
