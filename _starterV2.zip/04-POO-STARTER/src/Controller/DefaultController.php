<?php

namespace Controller;


/**
 * L'Objectif du DefaultController est de s'occuper
 * de la gestion des pages principales du site.
 * ----------------------------
 * En héritant de AbstractController, ma classe
 * DefaultController à maintenant accès à l'ensemble
 * des propriétés et méthodes de AbstractController.
 * NOTA BENE : Une classe ne peut hériter que d'une
 * et une seule autre classe.
 * ------------------------------
 */
class DefaultController extends AbstractController
{

    /**
     * La fonction "home" est ce qu'on appelle
     * une "action". Une action est une page.
     * -----------------
     * Page d'accueil du site
     */
    public function home()
    {
        $this->render('default/home');
    }

}
