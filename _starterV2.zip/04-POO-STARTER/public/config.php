<?php

# Connexion à la BDD
define( 'DB_HOST', 'localhost' );
define( 'DB_NAME', '' );
define( 'DB_USER', '' );
define( 'DB_PASS', '' );

# Configuration des chemins
define( 'PATH_ROOT', dirname(__FILE__, 2) );
define( 'PATH_PUBLIC', PATH_ROOT . '/public' );
define( 'PUBLIC_URL', '/public' );